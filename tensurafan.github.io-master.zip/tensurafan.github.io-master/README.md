# slime-reader
This is a web app to allow for users to read the fan translation of "That Time I Got Reincarnated as a Slime" with a few bonus features that are absent in PDF and EPub versions.

## Contributing
If you wish to suggest changes to novel contents, you can find the markdown files in: [ln/sources](ln/sources). \
To review how our specific flavor of Markdown works, see our [Markdown tutorial](https://tensurafan.github.io/Markdowntutorial).

## todo
- notifications maybe
- return to closed page on save
